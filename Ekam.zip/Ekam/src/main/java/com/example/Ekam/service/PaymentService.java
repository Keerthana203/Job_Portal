package com.example.Ekam.service;

import com.example.Ekam.dto.request.PaymentRequestDTO;
import com.example.Ekam.model.Bank;
import com.example.Ekam.model.CreditCard;
import com.example.Ekam.model.SubscriptionPayment;

import java.util.List;

public interface PaymentService {

    CreditCard addCard(CreditCard card, Integer userId, Integer subscriptionId);
    List<CreditCard> getCardsByUser(Long userId);
    Bank saveBank(String bankName, Integer userId, Integer subscriptionId);
    List<Bank> getBanksByUser(Long userId);
    SubscriptionPayment makePayment(PaymentRequestDTO request);
    List<SubscriptionPayment> getPaymentsByUser(Integer userId);
}
