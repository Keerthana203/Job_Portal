package com.example.Ekam.service.impl;


import com.example.Ekam.model.EnumEntity;
import com.example.Ekam.repository.EnumEntityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class EnumService {

    private final EnumEntityRepository enumEntityRepository;

    public EnumEntity getEnumByIdAndType(Integer id, String type) {
        EnumEntity entity = enumEntityRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Enum not found"));

        if (!type.equalsIgnoreCase(entity.getType())) {
            throw new RuntimeException("Enum type mismatch. Expected: " + type);
        }

        return entity;
    }

    public List<EnumEntity> getEnumsByType(String type) {
        return enumEntityRepository.findByTypeAndIsActive(type, true);
    }

}
