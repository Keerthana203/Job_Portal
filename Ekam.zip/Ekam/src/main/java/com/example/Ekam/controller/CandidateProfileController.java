package com.example.Ekam.controller;

import com.example.Ekam.dto.request.CandidateProfileRequestDTO;
import com.example.Ekam.dto.response.CandidateProfileResponseDTO;
import com.example.Ekam.service.CandidateProfileService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

@RestController
@RequestMapping("/api")
public class CandidateProfileController {

    private final CandidateProfileService candidateProfileService;

    public CandidateProfileController(CandidateProfileService candidateProfileService) {
        this.candidateProfileService = candidateProfileService;
    }

    @PostMapping("/{userId}/save")
    public ResponseEntity<String> saveOrUpdateProfile(
            @PathVariable Long userId,
            @RequestBody CandidateProfileRequestDTO requestDTO) {
        candidateProfileService.saveCandidateProfile(userId, requestDTO);
        return ResponseEntity.ok("Candidate profile saved successfully!");
    }

    /**
     * Get candidate profile by userId
     */
    @GetMapping("/{userId}/profile")
    public ResponseEntity<CandidateProfileResponseDTO> getCandidateProfile(@PathVariable Long userId) {
        CandidateProfileResponseDTO response = candidateProfileService.getCandidateProfile(userId);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/upload")
    public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile file) throws IOException {
        String uploadDir = "uploads/";
        String fileName = UUID.randomUUID() + "_" + file.getOriginalFilename();
        Path path = Paths.get(uploadDir + fileName);
        Files.createDirectories(path.getParent());
        Files.write(path, file.getBytes());

        String fileUrl = "http://localhost:8080/uploads/" + fileName;
        return ResponseEntity.ok(fileUrl);
    }

}
