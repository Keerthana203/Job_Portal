package com.example.Ekam.service.impl;

import com.example.Ekam.dto.request.JobPostRequestDTO;
import com.example.Ekam.dto.response.JobPostResponseDTO;
import com.example.Ekam.mapper.JobPostingMapper;
import com.example.Ekam.model.*;
import com.example.Ekam.repository.*;
import com.example.Ekam.service.JobPostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

//@Service
//public class JobPostServiceImpl implements JobPostService {
//
//    private final JobPostRepository jobPostRepository;
//    private final EmployersRepository employersRepository;
//    private final LocationRepository locationRepository;
//    private final JobCategoryRepository jobCategoryRepository;
//    private final EnumEntityRepository enumEntityRepository;
//    private final JobPostingMapper jobPostingMapper;
//    private final EnumService enumService;
//
//    @Autowired
//    public JobPostServiceImpl(JobPostRepository jobPostRepository,
//                              EmployersRepository employersRepository,
//                              LocationRepository locationRepository,
//                              JobCategoryRepository jobCategoryRepository,
//                              EnumEntityRepository enumEntityRepository,
//                              JobPostingMapper jobPostingMapper, EnumService enumService) {
//        this.jobPostRepository = jobPostRepository;
//        this.employersRepository = employersRepository;
//        this.locationRepository = locationRepository;
//        this.jobCategoryRepository = jobCategoryRepository;
//        this.enumEntityRepository = enumEntityRepository;
//        this.jobPostingMapper = jobPostingMapper;
//        this.enumService = enumService;
//    }
//
//    @Override
//    public JobPostResponseDTO createJob(JobPostRequestDTO dto) {
//        Employer employer = employersRepository.findByUser_UserId(dto.getUserId())
//                .orElseThrow(() -> new RuntimeException("Employer not found"));
//        Location location = locationRepository.findById(dto.getLocationId())
//                .orElseThrow(() -> new RuntimeException("Location not found"));
//        JobCategory category = jobCategoryRepository.findById(dto.getJobCategoryId())
//                .orElseThrow(() -> new RuntimeException("Category not found"));
////        EnumEntity jobType = enumEntityRepository.findById(dto.getJobTypeId())
////                .orElseThrow(() -> new RuntimeException("JobType not found"));
//        EnumEntity jobType = enumService.getEnumByIdAndType(dto.getJobTypeId(), "job_type");
//
//
//        JobPosting jobPosting = jobPostingMapper.toEntity(dto, employer, location, category, jobType);
//        jobPosting.setCreatedAt(LocalDateTime.now());
//
//        JobPosting saved = jobPostRepository.save(jobPosting);
//
//        return jobPostingMapper.toResponseDTO(saved);
//    }
//
//    @Override
//    public JobPosting updateJob(Integer id, JobPostRequestDTO dto) {
//        JobPosting existing = jobPostRepository.findById(id)
//                .orElseThrow(() -> new RuntimeException("Job not found"));
//
//        Employer employer = employersRepository.findByUser_UserId(dto.getUserId())
//                .orElseThrow(() -> new RuntimeException("Employer not found"));
//        Location location = locationRepository.findById(dto.getLocationId())
//                .orElseThrow(() -> new RuntimeException("Location not found"));
//        JobCategory category = jobCategoryRepository.findById(dto.getJobCategoryId())
//                .orElseThrow(() -> new RuntimeException("Category not found"));
//        EnumEntity jobType = enumEntityRepository.findById(dto.getJobTypeId())
//                .orElseThrow(() -> new RuntimeException("JobType not found"));
//
//        JobPosting updated = jobPostingMapper.toEntity(dto, employer, location, category, jobType);
//        updated.setId(existing.getId());
//        updated.setCreatedAt(existing.getCreatedAt()); // preserve created date
//
//        return jobPostRepository.save(updated);
//    }
//
//    @Override
//    public void deleteJob(Integer id) {
//        jobPostRepository.deleteById(id);
//    }
//
//    @Override
//    public List<JobPosting> getAllJobs() {
//        return jobPostRepository.findAll();
//    }
//
//    @Override
//    public JobPostResponseDTO getJobById(Integer id) {
//        return jobPostRepository.findById(id)
//                .orElseThrow(() -> new RuntimeException("Job not found"));
//    }
//
//}

@Service
public class JobPostServiceImpl implements JobPostService {

    private final JobPostRepository jobPostRepository;
    private final EmployersRepository employersRepository;
    private final LocationRepository locationRepository;
    private final JobCategoryRepository jobCategoryRepository;
    private final EnumEntityRepository enumEntityRepository;
    private final JobPostingMapper jobPostingMapper;
    private final EnumService enumService;

    @Autowired
    public JobPostServiceImpl(JobPostRepository jobPostRepository,
                              EmployersRepository employersRepository,
                              LocationRepository locationRepository,
                              JobCategoryRepository jobCategoryRepository,
                              EnumEntityRepository enumEntityRepository,
                              JobPostingMapper jobPostingMapper,
                              EnumService enumService) {
        this.jobPostRepository = jobPostRepository;
        this.employersRepository = employersRepository;
        this.locationRepository = locationRepository;
        this.jobCategoryRepository = jobCategoryRepository;
        this.enumEntityRepository = enumEntityRepository;
        this.jobPostingMapper = jobPostingMapper;
        this.enumService = enumService;
    }

    @Override
    public JobPostResponseDTO createJob(JobPostRequestDTO dto) {
        Employer employer = employersRepository.findByUser_UserId(dto.getUserId())
                .orElseThrow(() -> new RuntimeException("Employer not found"));
        Location location = locationRepository.findById(dto.getLocationId())
                .orElseThrow(() -> new RuntimeException("Location not found"));
        JobCategory category = jobCategoryRepository.findById(dto.getJobCategoryId())
                .orElseThrow(() -> new RuntimeException("Category not found"));

        EnumEntity jobType = enumService.getEnumByIdAndType(dto.getJobTypeId(), "job_type");

        JobPosting jobPosting = jobPostingMapper.toEntity(dto, employer, location, category, jobType);
        jobPosting.setCreatedAt(LocalDateTime.now());

        JobPosting saved = jobPostRepository.save(jobPosting);

        return jobPostingMapper.toResponseDTO(saved);
    }

    @Override
    public JobPostResponseDTO updateJob(Integer id, JobPostRequestDTO dto) {
        JobPosting existing = jobPostRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Job not found"));

        Employer employer = employersRepository.findByUser_UserId(dto.getUserId())
                .orElseThrow(() -> new RuntimeException("Employer not found"));
        Location location = locationRepository.findById(dto.getLocationId())
                .orElseThrow(() -> new RuntimeException("Location not found"));
        JobCategory category = jobCategoryRepository.findById(dto.getJobCategoryId())
                .orElseThrow(() -> new RuntimeException("Category not found"));
        EnumEntity jobType = enumEntityRepository.findById(dto.getJobTypeId())
                .orElseThrow(() -> new RuntimeException("JobType not found"));

        JobPosting updated = jobPostingMapper.toEntity(dto, employer, location, category, jobType);
        updated.setId(existing.getId());
        updated.setCreatedAt(existing.getCreatedAt()); // preserve created date

        JobPosting saved = jobPostRepository.save(updated);

        return jobPostingMapper.toResponseDTO(saved);
    }

    @Override
    public void deleteJob(Integer id) {
        jobPostRepository.deleteById(id);
    }

    @Override
    public List<JobPostResponseDTO> getAllJobs() {
        return jobPostRepository.findAll()
                .stream()
                .map(jobPostingMapper::toResponseDTO)
                .toList();
    }

    @Override
    public JobPostResponseDTO getJobById(Integer id) {
        JobPosting job = jobPostRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Job not found"));
        return jobPostingMapper.toResponseDTO(job);
    }
}

