package com.example.Ekam.dto.request;


import lombok.Data;

@Data
public class CandidateRegistrationRequestDTO {
    private String firstname;
    private String lastname;
    private String email;
    private String mobileNumber;
    private String service;
    private String serviceStatus;
    private String ranking;
    private String branch;
    private Boolean hasCorporateExperience;
    //private Boolean subscribeToNewsletter;
}
