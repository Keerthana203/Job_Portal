package com.example.Ekam.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;


@Component
@RequiredArgsConstructor
public class JwtAuthFilter extends OncePerRequestFilter {

    private final JwtService jwtService;
    private final CustomUserDetailsService userDetailsService;

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException { //applies JWT auth on every request

        //filterchain - used to pass the request forward after processing

        //skip filter for /auth url's
        String path = request.getServletPath();
        if (path.startsWith("/api/auth")) {
            filterChain.doFilter(request, response);
            return;
        }


        //get token from header
        final String authHeader = request.getHeader("Authorization");
        final String token;
        final String username;



        //chks for authorization header and start with Bearer
        if (authHeader == null || !authHeader.startsWith("Bearer ")) { //chks for authoization: bearer<Token> in req header
            filterChain.doFilter(request, response);
            return;
        }

        token = authHeader.substring(7); //extracts the token and username from authHeader
        username = jwtService.extractUsername(token);


        //proceeds if user found or not authenticated
        if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
            // Get role from token
            String role = jwtService.extractAllClaims(token).get("role", String.class);
            System.out.println("role printed as: " + role);
            Long userId = jwtService.extractUserId(token);

            // Set authority based on role in token
            List<SimpleGrantedAuthority> authorities = List.of(new SimpleGrantedAuthority("ROLE_" + role));


            //load user from database by username
            UserDetails userDetails = userDetailsService.loadUserByUsername(username);

            if (jwtService.isTokenValid(token, userDetails.getUsername())) {
                //create authentication object (builds token)
                UsernamePasswordAuthenticationToken authToken =
                        new UsernamePasswordAuthenticationToken(userDetails, null, authorities);

                //add metadata like IP address
                authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

                //authenticated for current request
                SecurityContextHolder.getContext().setAuthentication(authToken);
                System.out.println(authToken);
            }
        }

        filterChain.doFilter(request, response); //pass req to controller method
    }

}
