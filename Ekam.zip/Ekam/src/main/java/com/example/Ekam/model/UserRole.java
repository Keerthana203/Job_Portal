package com.example.Ekam.model;

import jakarta.persistence.*;
import lombok.Data;


@Entity
@Data
@Table(name = "user_roles")
public class UserRole {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String role;

}
