package com.example.Ekam.dto.request;

import com.example.Ekam.model.Certifications;
import com.example.Ekam.model.Education;
import com.example.Ekam.model.WorkExperience;
import lombok.Data;

import java.util.List;

@Data
public class CandidateProfileRequestDTO {
    private String resumeUrl;
    private String photoUrl;
    private String coverLetterUrl;
    private String mobileNumber;

    private List<String> skills;
    private List<Education> educationList;
    private List<WorkExperience> workExperienceList;
    private List<Certifications> certifications;
    private List<String> socialMediaLinks;
}
