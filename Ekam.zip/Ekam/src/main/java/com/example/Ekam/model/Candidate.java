package com.example.Ekam.model;


import jakarta.persistence.*;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@Table(name = "candidates")
public class Candidate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @OneToOne
    @JoinColumn(name = "user_id", referencedColumnName = "user_id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "service_id")
    private JobService service;

    @ManyToOne
    @JoinColumn(name = "service_status_id")
    private ServiceStatus serviceStatus;

    @ManyToOne
    @JoinColumn(name = "rank_id")
    private Rankings rank_name;

    @ManyToOne
    @JoinColumn(name = "branch_id")
    private Branch branch;

    @Column(name = "mobile_number", length = 255)
    private String mobileNumber;

    @Column(name = "has_corporate_experience")
    private Boolean hasCorporateExperience;


    @Column(name = "photo_url")
    private String photoUrl;

    @Column(name = "resume_url")
    private String resumeUrl;

    @Column(name = "cover_letter_url")
    private String coverLetterUrl;

    @OneToMany(mappedBy = "candidate", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CandidateSkill> candidateSkills = new ArrayList<>();

    @OneToMany(mappedBy = "candidate", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Education> educations = new ArrayList<>();

    @OneToMany(mappedBy = "candidate", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<WorkExperience> workExperiences = new ArrayList<>();

    @OneToMany(mappedBy = "candidate", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Certifications> certifications = new ArrayList<>();

    @OneToMany(mappedBy = "candidate", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CandidateSocialMediaLink> socialMediaLinks = new ArrayList<>();

}
