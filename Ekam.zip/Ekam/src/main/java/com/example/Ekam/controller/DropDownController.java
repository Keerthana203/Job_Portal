package com.example.Ekam.controller;


import com.example.Ekam.model.*;
import com.example.Ekam.service.DropDownService;
import com.example.Ekam.service.impl.EnumService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class DropDownController {

    @Autowired
    private DropDownService dropDownService;
    private final EnumService enumService;

    @GetMapping("/services")
    public List<JobService> getAllServices() {
        return dropDownService.getAllServices();
    }

    @GetMapping("/service-status")
    public List<ServiceStatus> getAllStatus() {
        return dropDownService.getAllStatus();
    }

    @GetMapping("/ranks")
    public List<Rankings> getAllRanks() {
        return dropDownService.getAllRanks();
    }

    @GetMapping("/branch")
    public List<Branch> getAllBranch() {
        return dropDownService.getAllBranch();
    }

    @GetMapping("/category")
    public List<JobCategory> getAllCategory() {
        return dropDownService.getAllCategory();
    }

    @GetMapping("/locations")
    public List<Location> getLocations() {
        return dropDownService.getLocations();
    }

    @GetMapping("/type/{type}")
    public ResponseEntity<List<EnumEntity>> getEnumsByType(@PathVariable String type) {
        return ResponseEntity.ok(enumService.getEnumsByType(type));
    }

    @GetMapping("/skills")
    public List<Skills> getSKills() { return dropDownService.getSkills(); }
}
