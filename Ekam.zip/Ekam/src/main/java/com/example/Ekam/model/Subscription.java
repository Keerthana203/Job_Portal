package com.example.Ekam.model;


import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Data
@Table(name = "subscriptions")
public class Subscription {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String name;
    private BigDecimal price;

    @Column(name = "max_hires")
    private Integer maxHires;

    @Column(name = "job_slots")
    private Integer jobSlots;

    @Column(name = "job_branding")
    private Integer jobBranding;

    @Column(name = "cv_views")
    private Integer cvViews;

    @Column(name = "search_results")
    private Integer searchResults;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}
