package com.example.Ekam.dto.request;


import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class SendOtpRequestDTO {

    private String email;
    private String purpose; // e.g. EMAIL_VERIFICATION, FORGOT_PASSWORD, LOGIN_OTP
//    private String role;
}
