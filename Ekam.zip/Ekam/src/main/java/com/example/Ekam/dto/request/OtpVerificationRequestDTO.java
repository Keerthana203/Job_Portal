package com.example.Ekam.dto.request;


import lombok.Data;

@Data
public class OtpVerificationRequestDTO {
    private String email;
    private String otpCode;
}
