package com.example.Ekam.repository;

import com.example.Ekam.model.PendingCandidate;
import com.example.Ekam.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
@Repository
public interface PendingCandidateRepository extends JpaRepository<PendingCandidate, Long> {

    Optional<PendingCandidate> findByUser(User user);
    void deleteByUser(User user);

}
