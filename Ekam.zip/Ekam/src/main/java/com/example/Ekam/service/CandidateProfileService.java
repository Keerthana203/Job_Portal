package com.example.Ekam.service;

import com.example.Ekam.dto.request.CandidateProfileRequestDTO;
import com.example.Ekam.dto.response.CandidateProfileResponseDTO;
import com.example.Ekam.model.Candidate;

public interface CandidateProfileService {
    // Save/update candidate profile
    Candidate saveCandidateProfile(Long userId, CandidateProfileRequestDTO profileRequest);

    // Get candidate profile by userId
    CandidateProfileResponseDTO getCandidateProfile(Long userId);
}
