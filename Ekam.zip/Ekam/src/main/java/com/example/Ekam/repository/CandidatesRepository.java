package com.example.Ekam.repository;

import com.example.Ekam.model.Candidate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CandidatesRepository extends JpaRepository<Candidate, Integer> {
    Optional<Candidate> findByUser_UserId(Long userId);
}
