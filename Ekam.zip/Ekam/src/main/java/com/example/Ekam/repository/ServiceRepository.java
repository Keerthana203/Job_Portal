package com.example.Ekam.repository;

import com.example.Ekam.model.JobService;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ServiceRepository extends JpaRepository<JobService, Long> {
    Optional<JobService> findByService(String service);
}
