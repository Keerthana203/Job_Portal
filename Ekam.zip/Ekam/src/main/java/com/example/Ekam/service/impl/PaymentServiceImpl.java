package com.example.Ekam.service.impl;

import com.example.Ekam.dto.request.PaymentRequestDTO;
import com.example.Ekam.model.*;
import com.example.Ekam.repository.*;
import com.example.Ekam.service.PaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class PaymentServiceImpl implements PaymentService {

    private final CreditCardRepository creditCardRepository;
    private final UsersRepository usersRepository;
    private final EmployersRepository employersRepository;
    private final SubscriptionRepository subscriptionRepository;
    private final BankRepository bankRepository;
    private final SubscriptionPaymentRepository subscriptionPaymentRepository;
    private final EnumEntityRepository enumEntityRepository;

    @Override
    public CreditCard addCard(CreditCard card, Integer userId, Integer subscriptionId) {
        User user = usersRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        card.setUser(user);

        if (subscriptionId != null) {
            Subscription subscription = subscriptionRepository.findById(subscriptionId)
                    .orElseThrow(() -> new RuntimeException("Subscription not found"));
            card.setSubscription(subscription);
        }

        return creditCardRepository.save(card);
    }


    @Override
    public List<CreditCard> getCardsByUser(Long userId) {
        return creditCardRepository.findByUser_UserId(userId);
    }

    @Override
    public Bank saveBank(String bankName, Integer userId, Integer subscriptionId) {
        User user = usersRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Subscription subscription = subscriptionRepository.findById(subscriptionId)
                .orElseThrow(() -> new RuntimeException("Subscription not found"));

        Bank bank = new Bank();
        bank.setBankName(bankName);
        bank.setUser(user);
        bank.setSubscription(subscription);

        return bankRepository.save(bank);
    }

    @Override
    public List<Bank> getBanksByUser(Long userId) {
        return bankRepository.findByUser_UserId(userId);
    }

    @Override
    public SubscriptionPayment makePayment(PaymentRequestDTO request) {
        Employer employer = employersRepository.findByUser_UserId(request.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        Subscription subscription = subscriptionRepository.findById(request.getSubscriptionId())
                .orElseThrow(() -> new RuntimeException("Subscription not found"));


        SubscriptionPayment payment = new SubscriptionPayment();
        payment.setEmployer(employer);
        payment.setSubscription(subscription);
        payment.setAmountPaid(request.getAmount());
        payment.setPaymentDate(LocalDateTime.now());
        EnumEntity paymentMethod = enumEntityRepository.findById(request.getPaymentMethodId())
                .orElseThrow(() -> new RuntimeException("Invalid payment method"));

        payment.setPaymentMethod(paymentMethod);
        payment.setIsActive(true);

        if ("CREDIT_CARD".equalsIgnoreCase(paymentMethod.getValue()) && request.getCardId() != null) {
            CreditCard card = creditCardRepository.findById(request.getCardId())
                    .orElseThrow(() -> new RuntimeException("Card not found"));
            payment.setCreditCard(card);
        } else if ("NET_BANKING".equalsIgnoreCase(paymentMethod.getValue()) && request.getBankId() != null) {
            Bank bank = bankRepository.findById(request.getBankId())
                    .orElseThrow(() -> new RuntimeException("Bank not found"));
            payment.setBank(bank);
        }

        return subscriptionPaymentRepository.save(payment);
    }

    @Override
    public List<SubscriptionPayment> getPaymentsByUser(Integer userId) {
        return subscriptionPaymentRepository.findByEmployer_User_UserId(userId);
    }
}
