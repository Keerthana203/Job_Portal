package com.example.Ekam.model;


import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Entity
@Data
@Table(name = "pending_candidates")
public class PendingCandidate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @JoinColumn(name = "user_id", referencedColumnName = "user_id", nullable = false)
    private User user;

    @Column(name = "mobile_number")
    private String mobileNumber;

    @ManyToOne
    @JoinColumn(name = "service_id", nullable = false)
    private JobService service;

    @ManyToOne
    @JoinColumn(name = "service_status_id", nullable = false)
    private ServiceStatus serviceStatus;

    @ManyToOne
    @JoinColumn(name = "rank_id", nullable = false)
    private Rankings rank_name;

    @ManyToOne
    @JoinColumn(name = "branch_id", nullable = false)
    private Branch branch;

    @Column(name = "has_corporate_experience")
    private Boolean hasCorporateExperience;

    @Column(name = "created_at")
    private LocalDateTime createdAt;


}
