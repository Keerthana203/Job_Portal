package com.example.Ekam.service;

import com.example.Ekam.dto.request.*;
import com.example.Ekam.dto.response.LoginResponseDTO;
import com.example.Ekam.dto.response.RegistrationResponseDTO;

public interface AuthService {
    RegistrationResponseDTO registerCandidate(CandidateRegistrationRequestDTO requestDTO);
    RegistrationResponseDTO registerEmployer(EmployerRegistrationRequestDTO requestDTO);
    RegistrationResponseDTO sendOtp(SendOtpRequestDTO requestDTO);
    RegistrationResponseDTO verifyOtp(OtpVerificationRequestDTO requestDTO);
    RegistrationResponseDTO setupPassword(PasswordSetupRequestDTO requestDTO);
    RegistrationResponseDTO registerAdmin(AdminRegisterRequestDTO requestDTO);
    LoginResponseDTO login(LoginRequestDTO requestDTO);
//    String login(LoginRequestDTO requestDTO);

}
