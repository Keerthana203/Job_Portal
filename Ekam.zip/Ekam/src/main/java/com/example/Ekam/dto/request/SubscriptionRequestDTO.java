package com.example.Ekam.dto.request;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class SubscriptionRequestDTO {

    private String name;
    private BigDecimal price;
    private Integer maxHires;
    private Integer jobSlots;
    private Integer cvViews;
    private Integer searchResults;
    private Boolean isActive;

}
