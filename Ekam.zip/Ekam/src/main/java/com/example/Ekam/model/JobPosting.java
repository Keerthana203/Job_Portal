package com.example.Ekam.model;


import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@Data
@Table(name = "job_postings")
public class JobPosting {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id", referencedColumnName = "user_id")
    private Employer employer;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "location_id")
    private Location location;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "job_category_id")
    private JobCategory jobCategory;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "enum_type_id")
    private EnumEntity jobType;

    private String title;

    private String description;

    @Column(name = "salary_range")
    private String salaryRange;

    @Column(name = "required_qualification")
    private String requiredQualification;

    @Lob
    @Column(name = "roles_responsibilities", columnDefinition = "TEXT")
    private String rolesResponsibilities;

    private String experience;

    @Column(name = "benefits_perks")
    private String benefitsPerks;

    @Column(name = "documents_required")
    private String documentsRequired;

    @Column(name = "apply_before")
    private LocalDateTime applyBefore;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "is_active")
    private Boolean isActive;

    @OneToMany(mappedBy = "jobPosting", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<JobSkills> jobSkills = new HashSet<>();
}
