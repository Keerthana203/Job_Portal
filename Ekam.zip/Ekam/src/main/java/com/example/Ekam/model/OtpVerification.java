package com.example.Ekam.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;


@Entity
@Data
@Table(name = "otp_verification")
public class OtpVerification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", referencedColumnName = "user_id")
    private User user;

    private String email;
    private String phone;

    @Column(name = "otp_code")
    private String otpCode;

    // The ManyToOne relationship to your new Purpose entity
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "purpose_id") // Assuming your column is named purpose_id
    private Purpose purpose;

    @Column(name = "expires_at")
    private LocalDateTime expiresAt;

    @Column(name = "is_used")
    private Boolean isUsed;

    @Column(name = "created_at")
    private LocalDateTime createdAt;
}
