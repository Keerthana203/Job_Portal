package com.example.Ekam.controller;

import com.example.Ekam.dto.request.PaymentRequestDTO;
import com.example.Ekam.model.Bank;
import com.example.Ekam.model.CreditCard;
import com.example.Ekam.model.SubscriptionPayment;
import com.example.Ekam.service.PaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService paymentService;

    @PostMapping("/add")
    public ResponseEntity<CreditCard> addCard(
            @RequestBody CreditCard card,
            @RequestParam Integer userId,
            @RequestParam(required = false) Integer subscriptionId) {
        return ResponseEntity.ok(paymentService.addCard(card, userId, subscriptionId));
    }

    @GetMapping("/{userId}/card")
    public ResponseEntity<List<CreditCard>> getCardsByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(paymentService.getCardsByUser(userId));
    }

    // Save bank used for payment
    @PostMapping("/save")
    public Bank saveBank(@RequestParam String bankName,
                         @RequestParam Integer userId,
                         @RequestParam Integer subscriptionId) {
        return paymentService.saveBank(bankName, userId, subscriptionId);
    }

    // Get all banks used by a user
    @GetMapping("/{userId}/bank")
    public List<Bank> getBanksByUser(@PathVariable Long userId) {
        return paymentService.getBanksByUser(userId);
    }

    @PostMapping("/pay")
    public ResponseEntity<String> makePayment(@RequestBody PaymentRequestDTO request) {
        SubscriptionPayment payment = paymentService.makePayment(request);
        return ResponseEntity.ok("Payment saved successfully");
    }

    @GetMapping("/payment/{userId}")
    public ResponseEntity<List<SubscriptionPayment>> getPaymentsByUser(@PathVariable Integer userId) {
        List<SubscriptionPayment> payments = paymentService.getPaymentsByUser(userId);
        return ResponseEntity.ok(payments);
    }
}
