package com.example.Ekam.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

@Service
public class JwtService {

    @Value("${jwt.secret}")
    private String jwtSecret;

    @Value("${jwt.expiration}")
    private long jwtExpiration;

    //generate token with subject(email or password)
    public String generatedToken(String subject, String role, Long userId, String username){
        return Jwts.builder()
                .setSubject(subject) //user email
                .claim("role", role) //user
                .claim("userId", userId) //get the userID
                .claim("username", username)
                .setIssuedAt(new Date()) //token creation time
                .setExpiration(new Date(System.currentTimeMillis() + jwtExpiration)) //token expiry
                .signWith(getSignKey(), SignatureAlgorithm.HS256) //sign with secret key
                .compact(); //generate token
    }

    //Extract username from token
    public String extractUsername(String token){
        return extractClaim(token, Claims::getSubject); //extract sub field from JWT(username)
    }

    //extract userId from token
    public Long extractUserId(String token) {
        return extractAllClaims(token).get("userId", Long.class);
    }

    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver){ //generic method to extract any field from JWT
        final Claims claims = extractAllClaims(token); //extract all by parsing and applying lambda function like(claims::getSubject)
        return claimsResolver.apply(claims); //claims::getSubject is passed as claimResolver(specific field)
    }

    public boolean isTokenValid(String token, String email){
        final String username = extractUsername(token);
        return (username.equals(email) && !isTokenExpired(token));
    }

    public boolean isTokenExpired(String token){
        return extractClaim(token, Claims::getExpiration).before(new Date());
    }


    //parse the token and return all the claims in payload
    public Claims extractAllClaims(String token){
        return Jwts.parserBuilder()
                .setSigningKey(getSignKey())
                .build()
                .parseClaimsJws(token)
                .getBody();
    }

    private Key getSignKey(){ //converts jwt.secret into cryptographic key to sign and verify.
        return Keys.hmacShaKeyFor(jwtSecret.getBytes());
    }


    public String extractTokenFromRequest(HttpServletRequest request) {
        String authHeader = request.getHeader("Authorization");
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            return authHeader.substring(7); // remove "Bearer "
        }
        throw new RuntimeException("Missing or invalid Authorization header");
    }
}
