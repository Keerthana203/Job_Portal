package com.example.Ekam.model;


import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "institution")
public class Institution {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "location_id")
    private Location location;

    @Column(name = "institute_name")
    private String instituteName;
}
