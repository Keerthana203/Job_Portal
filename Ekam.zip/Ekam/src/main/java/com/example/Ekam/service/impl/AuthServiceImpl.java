package com.example.Ekam.service.impl;

import com.example.Ekam.dto.request.*;
import com.example.Ekam.dto.response.LoginResponseDTO;
import com.example.Ekam.dto.response.RegistrationResponseDTO;
import com.example.Ekam.model.*;
import com.example.Ekam.repository.*;
import com.example.Ekam.security.JwtService;
import com.example.Ekam.service.AuthService;
import com.example.Ekam.service.EmailService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Random;

@Service
public class AuthServiceImpl implements AuthService {

    private final UsersRepository usersRepository;
    private final CandidatesRepository candidatesRepository;
    private final EmployersRepository employersRepository;
    private final PendingCandidateRepository pendingCandidateRepository;
    private final PendingEmployerRepository pendingEmployerRepository;
    private final OtpVerificationRepository otpVerificationRepository;
    private final UserRoleRepository userRoleRepository;
    private final PurposeRepository purposeRepository;
    private final ServiceRepository serviceRepository;
    private final ServiceStatusRepository serviceStatusRepository;
    private final RankRepository rankRepository;
    private final BranchRepository branchRepository;
    private final CompanyRepository companyRepository;
    private final PasswordEncoder passwordEncoder;
    private final EmailService emailService;
    private final AuthenticationManager authenticationManager;
    private final UserDetailsService userDetailsService;
    private final JwtService jwtService;

    // Use constructor injection for ALL dependencies to ensure they are never null
    @Autowired
    public AuthServiceImpl(UsersRepository usersRepository, CandidatesRepository candidatesRepository,
                           EmployersRepository employersRepository, PendingCandidateRepository pendingCandidateRepository,PendingEmployerRepository pendingEmployerRepository,
                           OtpVerificationRepository otpVerificationRepository,
                           UserRoleRepository userRoleRepository, PurposeRepository purposeRepository,
                           PasswordEncoder passwordEncoder, EmailService emailService,
                           AuthenticationManager authenticationManager, UserDetailsService userDetailsService,
                           JwtService jwtService, ServiceRepository serviceRepository,
                           ServiceStatusRepository serviceStatusRepository,
                           RankRepository rankRepository,
                           BranchRepository branchRepository, CompanyRepository companyRepository) {
        this.usersRepository = usersRepository;
        this.candidatesRepository = candidatesRepository;
        this.employersRepository = employersRepository;
        this.pendingCandidateRepository = pendingCandidateRepository;
        this.pendingEmployerRepository = pendingEmployerRepository;
        this.otpVerificationRepository = otpVerificationRepository;
        this.userRoleRepository = userRoleRepository;
        this.purposeRepository = purposeRepository;
        this.passwordEncoder = passwordEncoder;
        this.emailService = emailService;
        this.authenticationManager = authenticationManager;
        this.userDetailsService = userDetailsService;
        this.jwtService = jwtService;
        this.serviceRepository = serviceRepository;
        this.serviceStatusRepository = serviceStatusRepository;
        this.rankRepository = rankRepository;
        this.branchRepository = branchRepository;
        this.companyRepository = companyRepository;
    }


    @Override
    @Transactional
    public RegistrationResponseDTO registerCandidate(CandidateRegistrationRequestDTO requestDTO) {
        if (usersRepository.findByEmail(requestDTO.getEmail()).isPresent()) {
            return new RegistrationResponseDTO("Error: Email is already in use!", null);
        }

        // Create User
        User user = new User();
        user.setFirstname(requestDTO.getFirstname());
        user.setLastname(requestDTO.getLastname());
        user.setEmail(requestDTO.getEmail());
        user.setIsVerified(false);
        user.setIsActive(true);
        user.setCreatedAt(LocalDateTime.now());

        UserRole candidateRole = userRoleRepository.findByRole("CANDIDATE")
                .orElseThrow(() -> new RuntimeException("Error: Role not found."));
        user.setRole(candidateRole);

        user.setPassword(passwordEncoder.encode("temp_password"));
        User savedUser = usersRepository.save(user);

        // Fetch entities from IDs
        JobService serviceEntity = serviceRepository.findByService(requestDTO.getService())
                .orElseThrow(() -> new RuntimeException("Service not found"));

        ServiceStatus serviceStatusEntity = serviceStatusRepository.findByStatus(requestDTO.getServiceStatus())
                .orElseThrow(() -> new RuntimeException("ServiceStatus not found"));

        Rankings rankEntity = rankRepository.findByRankingIgnoreCase(requestDTO.getRanking().trim())
                .orElseThrow(() -> new RuntimeException("Rank not found"));

        Branch branchEntity = branchRepository.findByBranch(requestDTO.getBranch())
                .orElseThrow(() -> new RuntimeException("Branch not found"));

        // Save pending candidate details
        PendingCandidate pendingCandidate = new PendingCandidate();
        pendingCandidate.setUser(savedUser);
        pendingCandidate.setMobileNumber(requestDTO.getMobileNumber());
        pendingCandidate.setService(serviceEntity);
        pendingCandidate.setServiceStatus(serviceStatusEntity);
        pendingCandidate.setRank_name(rankEntity);
        pendingCandidate.setBranch(branchEntity);
        pendingCandidate.setHasCorporateExperience(requestDTO.getHasCorporateExperience());
        pendingCandidate.setCreatedAt(LocalDateTime.now());
        pendingCandidateRepository.save(pendingCandidate);

        sendOtp(new SendOtpRequestDTO(requestDTO.getEmail(), "EMAIL_VERIFICATION"));

        return new RegistrationResponseDTO("User registered successfully. Check your email for OTP.", savedUser.getUserId());
    }




    @Override
    @Transactional
    public RegistrationResponseDTO registerEmployer(EmployerRegistrationRequestDTO requestDTO) {
        if (usersRepository.findByEmail(requestDTO.getEmail()).isPresent()) {
            return new RegistrationResponseDTO("Error: Email is already in use!", null);
        }

        User user = new User();
        user.setFirstname(requestDTO.getFirstname());
        user.setLastname(requestDTO.getLastname());
        user.setEmail(requestDTO.getEmail());
        user.setIsVerified(false);
        user.setIsActive(true);
        user.setCreatedAt(LocalDateTime.now());

        UserRole employerRole = userRoleRepository.findByRole("EMPLOYER")
                .orElseThrow(() -> new RuntimeException("Error: Role not found."));
        user.setRole(employerRole);

        user.setPassword(passwordEncoder.encode("temp_password"));
        User savedUser = usersRepository.save(user);



        PendingEmployer pendingEmployer = new PendingEmployer();
        pendingEmployer.setUser(savedUser);
        pendingEmployer.setMobileNumber(requestDTO.getMobileNumber());
        pendingEmployer.setCompanyName(requestDTO.getCompanyName());
        pendingEmployer.setCompanySize(requestDTO.getCompanySize());
        pendingEmployer.setCreatedAt(LocalDateTime.now());
        pendingEmployerRepository.save(pendingEmployer);

        sendOtp(new SendOtpRequestDTO(requestDTO.getEmail(), "EMAIL_VERIFICATION"));

        return new RegistrationResponseDTO("Employer registered successfully. Check your email for OTP.", savedUser.getUserId());
    }

    @Override
    @Transactional
    public RegistrationResponseDTO sendOtp(SendOtpRequestDTO requestDTO) {
        // 1. Find user
        User user = usersRepository.findByEmail(requestDTO.getEmail())
                .orElseThrow(() -> new RuntimeException("User not found. Please register first."));

        // 2. Generate OTP
        String otpCode = String.valueOf(100000 + new Random().nextInt(900000));

        // 3. Save OTP
        Purpose purpose = purposeRepository.findByPurpose(requestDTO.getPurpose())
                .orElseThrow(() -> new RuntimeException("Error: Purpose not found."));

        OtpVerification otp = new OtpVerification();
        otp.setUser(user);
        otp.setEmail(user.getEmail());
        otp.setOtpCode(otpCode);
        otp.setPurpose(purpose);
        otp.setExpiresAt(LocalDateTime.now().plusMinutes(5));
        otp.setIsUsed(false);
        otp.setCreatedAt(LocalDateTime.now());
        System.out.println("OTP is stored in the table");

        otpVerificationRepository.save(otp);

        // 4. Send OTP via email
        emailService.sendOtp(user.getEmail(), otpCode);

        return new RegistrationResponseDTO("OTP sent successfully to " + user.getEmail(), user.getUserId());
    }



    @Override
    @Transactional
    public RegistrationResponseDTO verifyOtp(OtpVerificationRequestDTO requestDTO) {
        Optional<OtpVerification> otpVerification = otpVerificationRepository.findByEmailAndOtpCodeAndExpiresAtAfterAndIsUsedFalse(
                requestDTO.getEmail(),
                requestDTO.getOtpCode(),
                LocalDateTime.now()
        );

        if (otpVerification.isPresent()) {
            OtpVerification otp = otpVerification.get();
            User user = otp.getUser();

            // Verify user
            user.setIsVerified(true);
            usersRepository.save(user);

            // Mark OTP as used
            otp.setIsUsed(true);
            otpVerificationRepository.save(otp);



            Integer roleId = user.getRole().getId();

            if (roleId == 1) {

                // Move data from PendingCandidate to Candidate
                PendingCandidate pendingCandidate = pendingCandidateRepository.findByUser(user)
                        .orElseThrow(() -> new RuntimeException("Pending candidate data not found"));


                Candidate candidate = new Candidate();
                candidate.setUser(user);
                candidate.setMobileNumber(pendingCandidate.getMobileNumber());
                candidate.setService(pendingCandidate.getService());
                candidate.setServiceStatus(pendingCandidate.getServiceStatus());
                candidate.setRank_name(pendingCandidate.getRank_name());
                candidate.setBranch(pendingCandidate.getBranch());
                candidate.setHasCorporateExperience(pendingCandidate.getHasCorporateExperience());
//            candidate.setSubscribeToNewsletter(pendingCandidate.getSubscribeToNewsletter());
                candidatesRepository.save(candidate);

                // Optional: Remove pending candidate after migration
                pendingCandidateRepository.delete(pendingCandidate);
            } else if (roleId == 2){

                PendingEmployer pendingEmployer = pendingEmployerRepository.findByUser(user)
                        .orElseThrow(() -> new RuntimeException("Pending Employer data not found"));

                Employer employer = new Employer();
                employer.setUser(user);
                employer.setMobileNumber(pendingEmployer.getMobileNumber());
                Employer savedEmployer = employersRepository.save(employer);

                Company company = new Company();
                company.setCompanyName(pendingEmployer.getCompanyName());
                company.setCompanySize(pendingEmployer.getCompanySize());
                company.setEmployer(savedEmployer);
                companyRepository.save(company);



                pendingEmployerRepository.delete(pendingEmployer);
            }

            System.out.println("otp is present");

            return new RegistrationResponseDTO("OTP verified successfully. You can now set your password.", user.getUserId());
        } else {
            System.out.println("Otp is not visible");
            return new RegistrationResponseDTO("Invalid or expired OTP.", null);
        }
    }



    @Override
    @Transactional
    public RegistrationResponseDTO setupPassword(PasswordSetupRequestDTO requestDTO) {
        Optional<User> userOptional = usersRepository.findByEmail(requestDTO.getEmail());
        if (userOptional.isPresent()) {
            User user = userOptional.get();
            if (user.getIsVerified()) {
                String hashedPassword = passwordEncoder.encode(requestDTO.getPassword());
                user.setPassword(hashedPassword);
                usersRepository.save(user);
                return new RegistrationResponseDTO("Password set successfully. You can now log in.", user.getUserId());
            } else {
                return new RegistrationResponseDTO("User is not verified. Please verify your email first.", null);
            }
        } else {
            return new RegistrationResponseDTO("User not found.", null);
        }
    }

    @Override
    public RegistrationResponseDTO registerAdmin(AdminRegisterRequestDTO requestDTO) {
        if (usersRepository.findByEmail(requestDTO.getEmail()).isPresent()) {
            throw new RuntimeException("Email already exists!");
        }

        UserRole adminRole = userRoleRepository.findByRole("ADMIN")
                .orElseThrow(() -> new RuntimeException("Role ADMIN not found"));

        User admin = new User();
        admin.setEmail(requestDTO.getEmail());
        admin.setPassword(passwordEncoder.encode(requestDTO.getPassword()));
        admin.setFirstname(requestDTO.getFirstname());
        admin.setLastname(requestDTO.getLastname());
        admin.setIsActive(true);
        admin.setIsVerified(true);
        admin.setCreatedAt(LocalDateTime.now());
        admin.setRole(adminRole);
        usersRepository.save(admin);

        return new RegistrationResponseDTO("Admin Registered Successfully.", null);
    }

    @Override
    public LoginResponseDTO login(LoginRequestDTO requestDTO) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(requestDTO.getEmail(), requestDTO.getPassword())
        );

        User user = usersRepository.findByEmail(requestDTO.getEmail())
                .orElseThrow(() -> new BadCredentialsException("User not found after successful authentication."));

        UserDetails userDetails = userDetailsService.loadUserByUsername(requestDTO.getEmail());

        String subject = userDetails.getUsername();
        String role = user.getRole().getRole();
        Long userId = Long.valueOf(user.getUserId());
        String username = user.getFirstname();

        String jwtToken = jwtService.generatedToken(subject, role, userId, username);

        return new LoginResponseDTO("Login successful!", jwtToken, userId);
    }
}

