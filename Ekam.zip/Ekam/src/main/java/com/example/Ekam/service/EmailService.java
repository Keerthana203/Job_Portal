package com.example.Ekam.service;

public interface EmailService {
    void sendOtp(String to, String otp);
}
