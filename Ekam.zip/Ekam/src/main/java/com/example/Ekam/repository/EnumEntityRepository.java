package com.example.Ekam.repository;


import com.example.Ekam.model.EnumEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EnumEntityRepository extends JpaRepository<EnumEntity, Integer> {

    List<EnumEntity> findByTypeAndIsActive(String type, Boolean isActive);

}
