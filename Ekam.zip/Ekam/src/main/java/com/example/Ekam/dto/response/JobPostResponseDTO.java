package com.example.Ekam.dto.response;

import lombok.Data;

import java.time.LocalDateTime;


@Data
public class JobPostResponseDTO {

    private Integer id;
    private String title;
    private String description;
    private String salaryRange;
    private String requiredQualification;
    private String rolesResponsibilities;
    private String experience;
    private String benefitsPerks;
    private String documentsRequired;
    private LocalDateTime applyBefore;
    private Boolean isActive;

    private Integer employerId;
    private Integer locationId;
    private Integer jobCategoryId;
    private Integer jobTypeId;
}
