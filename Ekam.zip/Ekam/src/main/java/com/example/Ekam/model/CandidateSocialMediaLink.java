package com.example.Ekam.model;

import jakarta.persistence.*;
import lombok.Data;


@Entity
@Data
@Table(name = "candidate_social_media_links")
public class CandidateSocialMediaLink {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "candidate_id")
    private Candidate candidate;

    private String links;
}
