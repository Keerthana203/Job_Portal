package com.example.Ekam.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "industry")
public class Industry {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String industry;
}
