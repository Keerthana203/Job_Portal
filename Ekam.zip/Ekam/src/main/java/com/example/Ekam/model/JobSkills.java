package com.example.Ekam.model;


import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "job_skills")
public class JobSkills {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "job_post_id")
    private JobPosting jobPosting;

    @ManyToOne
    @JoinColumn(name = "skill_id")
    private Skills skill;

}
