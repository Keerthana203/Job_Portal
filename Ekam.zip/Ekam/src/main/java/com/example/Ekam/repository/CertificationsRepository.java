package com.example.Ekam.repository;

import com.example.Ekam.model.Certifications;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CertificationsRepository extends JpaRepository<Certifications, Integer> {
    List<Certifications> findByCandidate_User_UserId(Long userId);
}
