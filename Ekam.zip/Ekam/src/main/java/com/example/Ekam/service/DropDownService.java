package com.example.Ekam.service;

import com.example.Ekam.model.*;

import java.util.List;

public interface DropDownService {
    List<JobService> getAllServices();
    List<ServiceStatus> getAllStatus();
    List<Rankings> getAllRanks();
    List<Branch> getAllBranch();
    List<JobCategory> getAllCategory();
    List<Location> getLocations();
    List<Skills> getSkills();
}
