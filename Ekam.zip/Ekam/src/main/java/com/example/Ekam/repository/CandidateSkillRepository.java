package com.example.Ekam.repository;

import com.example.Ekam.model.CandidateSkill;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CandidateSkillRepository extends JpaRepository<CandidateSkill, Integer> {
    List<CandidateSkill> findByCandidate_User_UserId(Long userId);
}
