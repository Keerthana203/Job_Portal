package com.example.Ekam.service;

import com.example.Ekam.dto.request.JobPostRequestDTO;
import com.example.Ekam.dto.response.JobPostResponseDTO;
import com.example.Ekam.model.JobPosting;

import java.util.List;

public interface JobPostService {

    JobPostResponseDTO createJob(JobPostRequestDTO dto);
    JobPostResponseDTO updateJob(Integer id, JobPostRequestDTO dto);
    void deleteJob(Integer id);
    List<JobPostResponseDTO> getAllJobs();
    JobPostResponseDTO getJobById(Integer id);
}
