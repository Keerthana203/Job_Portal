package com.example.Ekam.model;


import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "enum_table")
public class EnumEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String type;

    private String value;

    @Column(name = "is_active")
    private Boolean isActive;
}
