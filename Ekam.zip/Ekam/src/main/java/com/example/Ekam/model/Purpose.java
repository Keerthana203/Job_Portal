package com.example.Ekam.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "purpose")
public class Purpose {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "purpose")
    private String purpose;

}
