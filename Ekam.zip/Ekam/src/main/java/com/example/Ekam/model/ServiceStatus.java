package com.example.Ekam.model;


import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "service_status")
public class ServiceStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "service_status")
    private String status;
}
