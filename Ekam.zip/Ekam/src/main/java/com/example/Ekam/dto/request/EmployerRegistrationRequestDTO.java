package com.example.Ekam.dto.request;


import lombok.Data;

@Data
public class EmployerRegistrationRequestDTO {
    private String firstname;
    private String lastname;
    private String email;
    private String mobileNumber;
    private String companyName;
    private Integer companySize;
}
