package com.example.Ekam.model;

import jakarta.persistence.*;
import lombok.Data;


@Entity
@Data
@Table(name = "services")
public class JobService {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "service")
    private String service;
}
