package com.example.Ekam.model;


import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "job_category")
public class JobCategory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String category;
}
