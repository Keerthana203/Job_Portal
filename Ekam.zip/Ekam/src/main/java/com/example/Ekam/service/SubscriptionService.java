package com.example.Ekam.service;

import com.example.Ekam.dto.request.SubscriptionRequestDTO;
import com.example.Ekam.model.Subscription;

import java.util.List;

public interface SubscriptionService {
    Subscription createSubscription(SubscriptionRequestDTO dto);
    Subscription updateSubscription(Integer id, SubscriptionRequestDTO dto);
    void deleteSubscription(Integer id);
    List<Subscription> getAllSubscriptions();
    Subscription getSubscriptionById(Integer id);
}
