package com.example.Ekam.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;


@Entity
@Data
@Table(name = "pending_employers")
public class PendingEmployer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @JoinColumn(name = "user_id", referencedColumnName = "user_id", nullable = false)
    private User user;

    @Column(name = "mobile_number", nullable = false)
    private String mobileNumber;

    @Column(name = "company_name")
    private String companyName;

    @Column(name = "company_size")
    private Integer companySize;

    @Column(name = "created_at")
    private LocalDateTime createdAt;
}
