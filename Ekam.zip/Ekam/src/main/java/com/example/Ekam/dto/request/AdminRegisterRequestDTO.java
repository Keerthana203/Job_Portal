package com.example.Ekam.dto.request;


import lombok.Data;

@Data
public class AdminRegisterRequestDTO {

    private String email;
    private String password;
    private String firstname;
    private String lastname;

}
