package com.example.Ekam.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "credit_card_table")
public class CreditCard {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String last4; // last 4 digits

    @Column(nullable = false)
    private String expiry; // MM/YY

    @Column(nullable = false)
    private String nameOnCard;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    @JsonIgnore
    private User user;

    @ManyToOne
    @JoinColumn(name = "subscription_id", nullable = true)
    @JsonIgnore
    private Subscription subscription;

    @Column(nullable = false)
    private boolean isDefault = false;
}
