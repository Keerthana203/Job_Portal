package com.example.Ekam.service.impl;


import com.example.Ekam.dto.request.SubscriptionRequestDTO;
import com.example.Ekam.model.Subscription;
import com.example.Ekam.repository.SubscriptionRepository;
import com.example.Ekam.service.SubscriptionService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class SubscriptionServiceImpl implements SubscriptionService {

    private final SubscriptionRepository subscriptionRepository;

    @Override
    public Subscription createSubscription(SubscriptionRequestDTO dto) {
        Subscription subscription = new Subscription();
        subscription.setName(dto.getName());
        subscription.setPrice(dto.getPrice());
        subscription.setMaxHires(dto.getMaxHires());
        subscription.setJobSlots(dto.getJobSlots());
        subscription.setCvViews(dto.getCvViews());
        subscription.setSearchResults(dto.getSearchResults());
        subscription.setIsActive(true);
        subscription.setCreatedAt(LocalDateTime.now());
        subscription.setUpdatedAt(LocalDateTime.now());
        return subscriptionRepository.save(subscription);
    }

    @Override
    public Subscription updateSubscription(Integer id, SubscriptionRequestDTO dto) {
        Subscription subscription = subscriptionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Subscription not found"));

        subscription.setName(dto.getName());
        subscription.setPrice(dto.getPrice());
        subscription.setMaxHires(dto.getMaxHires());
        subscription.setJobSlots(dto.getJobSlots());
        subscription.setCvViews(dto.getCvViews());
        subscription.setSearchResults(dto.getSearchResults());
        subscription.setUpdatedAt(LocalDateTime.now());

        return subscriptionRepository.save(subscription);
    }

    @Override
    public void deleteSubscription(Integer id) {
        subscriptionRepository.deleteById(id);
    }

    @Override
    public List<Subscription> getAllSubscriptions() {
        return subscriptionRepository.findAll();
    }

    @Override
    public Subscription getSubscriptionById(Integer id) {
        return subscriptionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Subscription not found"));
    }

}
