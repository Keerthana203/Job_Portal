package com.example.Ekam.mapper;


import com.example.Ekam.dto.request.JobPostRequestDTO;
import com.example.Ekam.dto.response.JobPostResponseDTO;
import com.example.Ekam.model.*;
import org.springframework.stereotype.Component;

@Component
public class JobPostingMapper {

    public JobPosting toEntity(JobPostRequestDTO dto,
                               Employer employer,
                               Location location,
                               JobCategory jobCategory,
                               EnumEntity jobType) {
        JobPosting jobPosting = new JobPosting();
        jobPosting.setEmployer(employer);
        jobPosting.setLocation(location);
        jobPosting.setJobCategory(jobCategory);
        jobPosting.setJobType(jobType);

        jobPosting.setTitle(dto.getTitle());
        jobPosting.setDescription(dto.getDescription());
        jobPosting.setSalaryRange(dto.getSalaryRange());
        jobPosting.setRequiredQualification(dto.getRequiredQualification());
        jobPosting.setRolesResponsibilities(dto.getRolesResponsibilities());
        jobPosting.setExperience(dto.getExperience());
        jobPosting.setBenefitsPerks(dto.getBenefitsPerks());
        jobPosting.setDocumentsRequired(dto.getDocumentsRequired());
        jobPosting.setApplyBefore(dto.getApplyBefore());
        jobPosting.setIsActive(dto.getIsActive());

        return jobPosting;
    }


    public JobPostResponseDTO toResponseDTO(JobPosting jobPosting) {
        JobPostResponseDTO dto = new JobPostResponseDTO();
        dto.setId(jobPosting.getId());
        dto.setTitle(jobPosting.getTitle());
        dto.setDescription(jobPosting.getDescription());
        dto.setSalaryRange(jobPosting.getSalaryRange());
        dto.setRequiredQualification(jobPosting.getRequiredQualification());
        dto.setRolesResponsibilities(jobPosting.getRolesResponsibilities());
        dto.setExperience(jobPosting.getExperience());
        dto.setBenefitsPerks(jobPosting.getBenefitsPerks());
        dto.setDocumentsRequired(jobPosting.getDocumentsRequired());
        dto.setApplyBefore(jobPosting.getApplyBefore());
        dto.setIsActive(jobPosting.getIsActive());

        dto.setEmployerId(jobPosting.getEmployer().getId());
        dto.setLocationId(jobPosting.getLocation().getId());
        dto.setJobCategoryId(jobPosting.getJobCategory().getId());
        dto.setJobTypeId(jobPosting.getJobType().getId());

        return dto;
    }
}
