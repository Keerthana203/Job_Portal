package com.example.Ekam.controller;


import com.example.Ekam.dto.request.JobPostRequestDTO;
import com.example.Ekam.dto.response.JobPostResponseDTO;
import com.example.Ekam.model.EnumEntity;
import com.example.Ekam.model.JobPosting;
import com.example.Ekam.service.JobPostService;
import com.example.Ekam.service.impl.EnumService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/jobs")

@RequiredArgsConstructor
public class JobPostingController {

//    private final JobPostService jobPostService;
//    private final EnumService enumService;
//
//
//    @PostMapping("/add-job")
//    public ResponseEntity<JobPosting> createJob(@RequestBody JobPostRequestDTO dto) {
//        return ResponseEntity.ok(jobPostService.createJob(dto));
//    }
//
//    @PutMapping("/update/{id}")
//    public ResponseEntity<JobPosting> updateJob(@PathVariable Integer id,
//                                                @RequestBody JobPostRequestDTO dto) {
//        return ResponseEntity.ok(jobPostService.updateJob(id, dto));
//    }
//
//
//    @DeleteMapping("/delete/{id}")
//    public ResponseEntity<Void> deleteJob(@PathVariable Integer id) {
//        jobPostService.deleteJob(id);
//        return ResponseEntity.noContent().build();
//    }
//
//    @GetMapping("/all-jobs")
//    public ResponseEntity<List<JobPosting>> getAllJobs() {
//        return ResponseEntity.ok(jobPostService.getAllJobs());
//    }
//
//    @GetMapping("/get-job/{id}")
//    public ResponseEntity<JobPostResponseDTO> getJobById(@PathVariable Integer id) {
//        return ResponseEntity.ok(jobPostService.getJobById(id));
//    }

//    @GetMapping("/type/{type}")
//    public ResponseEntity<List<EnumEntity>> getEnumsByType(@PathVariable String type) {
//        return ResponseEntity.ok(enumService.getEnumsByType(type));
//    }

    private final JobPostService jobPostService;
    private final EnumService enumService;

    @PostMapping("/add-job")
    public ResponseEntity<JobPostResponseDTO> createJob(@RequestBody JobPostRequestDTO dto) {
        return ResponseEntity.ok(jobPostService.createJob(dto));
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<JobPostResponseDTO> updateJob(@PathVariable Integer id,
                                                        @RequestBody JobPostRequestDTO dto) {
        return ResponseEntity.ok(jobPostService.updateJob(id, dto));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteJob(@PathVariable Integer id) {
        jobPostService.deleteJob(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/all-jobs")
    public ResponseEntity<List<JobPostResponseDTO>> getAllJobs() {
        return ResponseEntity.ok(jobPostService.getAllJobs());
    }

    @GetMapping("/get-job/{id}")
    public ResponseEntity<JobPostResponseDTO> getJobById(@PathVariable Integer id) {
        return ResponseEntity.ok(jobPostService.getJobById(id));
    }

}
