package com.example.Ekam.repository;

import com.example.Ekam.model.CandidateSocialMediaLink;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CandidateSocialMediaLinkRepository extends JpaRepository<CandidateSocialMediaLink, Integer> {
    List<CandidateSocialMediaLink> findByCandidate_User_UserId(Long UserId);
}
