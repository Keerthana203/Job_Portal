package com.example.Ekam.controller;


import com.example.Ekam.dto.request.SubscriptionRequestDTO;
import com.example.Ekam.model.Subscription;
import com.example.Ekam.service.SubscriptionService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class AdminController {

    private final SubscriptionService subscriptionService;

    @PostMapping("/add-subscriptions")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Subscription> createSubscription(@RequestBody SubscriptionRequestDTO dto) {
        return ResponseEntity.ok(subscriptionService.createSubscription(dto));
    }

    @PutMapping("/update-subscriptions/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Subscription> updateSubscription(@PathVariable Integer id,
                                                           @RequestBody SubscriptionRequestDTO dto) {
        return ResponseEntity.ok(subscriptionService.updateSubscription(id, dto));
    }

    @DeleteMapping("/subscriptions/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> deleteSubscription(@PathVariable Integer id) {
        subscriptionService.deleteSubscription(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/subscriptions")
    public ResponseEntity<List<Subscription>> getAllSubscriptions() {
        return ResponseEntity.ok(subscriptionService.getAllSubscriptions());
    }

    @GetMapping("/subscriptions/{id}")
    public ResponseEntity<Subscription> getSubscriptionById(@PathVariable Integer id) {
        return ResponseEntity.ok(subscriptionService.getSubscriptionById(id));
    }

}
