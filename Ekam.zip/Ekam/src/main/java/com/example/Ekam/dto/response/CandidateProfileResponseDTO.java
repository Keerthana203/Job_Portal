package com.example.Ekam.dto.response;

import com.example.Ekam.model.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CandidateProfileResponseDTO {
    private Integer userId;
    private String resumeUrl;
    private String photoUrl;
    private String coverLetterUrl;
    private String mobileNumber;
    private List<String> skills;
    private List<Education> educationList;
    private List<WorkExperience> workExperienceList;
    private List<Certifications> certifications;
    private List<String> socialMediaLinks;

    public static CandidateProfileResponseDTO fromEntity(Candidate candidate) {
        CandidateProfileResponseDTO dto = new CandidateProfileResponseDTO();
        dto.setUserId(candidate.getUser().getUserId());
        dto.setResumeUrl(candidate.getResumeUrl());
        dto.setPhotoUrl(candidate.getPhotoUrl());
        dto.setCoverLetterUrl(candidate.getCoverLetterUrl());
        dto.setMobileNumber(candidate.getMobileNumber());

        dto.setSkills(candidate.getCandidateSkills().stream()
                .map(cs -> cs.getSkill().getSkill())
                .toList());

        dto.setEducationList(candidate.getEducations());
        dto.setWorkExperienceList(candidate.getWorkExperiences());
        dto.setCertifications(candidate.getCertifications());
        dto.setSocialMediaLinks(candidate.getSocialMediaLinks().stream()
                .map(CandidateSocialMediaLink::getLinks)
                .toList());

        return dto;
    }
}
