package com.example.Ekam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@EntityScan(basePackages = "com.example.Ekam.model")
public class EkamApplication {

	public static void main(String[] args) {
		SpringApplication.run(EkamApplication.class, args);
	}

}
