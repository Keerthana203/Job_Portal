package com.example.Ekam.dto.request;


import lombok.Data;

import java.time.LocalDateTime;
import java.util.Set;

@Data
public class JobPostRequestDTO {

    private Integer userId;
    private Integer locationId;
    private Integer jobCategoryId;
    private Integer jobTypeId;
    private String title;
    private String description;
    private String salaryRange;
    private String requiredQualification;
    private String rolesResponsibilities;
    private String experience;
    private String benefitsPerks;
    private String documentsRequired;
    private LocalDateTime applyBefore;
    private Boolean isActive;

    private Set<Integer> jobSkillIds;

}
