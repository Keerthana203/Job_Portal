package com.example.Ekam.repository;

import com.example.Ekam.model.Employer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface EmployersRepository extends JpaRepository<Employer, Integer> {
    Optional<Employer> findByUser_UserId(Integer userId);
}
