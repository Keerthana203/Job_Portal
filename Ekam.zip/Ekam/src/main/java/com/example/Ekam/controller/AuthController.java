package com.example.Ekam.controller;

import com.example.Ekam.dto.request.*;
import com.example.Ekam.dto.response.LoginResponseDTO;
import com.example.Ekam.dto.response.RegistrationResponseDTO;
import com.example.Ekam.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("api/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/register-candidate")
    public ResponseEntity<RegistrationResponseDTO> registerCandidate(@RequestBody CandidateRegistrationRequestDTO requestDTO) {
        RegistrationResponseDTO response = authService.registerCandidate(requestDTO);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/register-employer")
    public ResponseEntity<RegistrationResponseDTO> registerEmployer(@RequestBody EmployerRegistrationRequestDTO requestDTO) {
        RegistrationResponseDTO response = authService.registerEmployer(requestDTO);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/register-admin")
    public ResponseEntity<RegistrationResponseDTO> registerAdmin(@RequestBody AdminRegisterRequestDTO requestDTO) {
        RegistrationResponseDTO response = authService.registerAdmin(requestDTO);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/send-otp")
    public ResponseEntity<RegistrationResponseDTO> sendOtp(@RequestBody SendOtpRequestDTO requestDTO) {
        RegistrationResponseDTO response = authService.sendOtp(requestDTO);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/verify-otp")
    public ResponseEntity<RegistrationResponseDTO> verifyOtp(@RequestBody OtpVerificationRequestDTO requestDTO) {
        RegistrationResponseDTO response = authService.verifyOtp(requestDTO);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/setup-password")
    public ResponseEntity<RegistrationResponseDTO> setupPassword(@RequestBody PasswordSetupRequestDTO requestDTO) {
        RegistrationResponseDTO response = authService.setupPassword(requestDTO);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponseDTO> login(@RequestBody LoginRequestDTO requestDTO) {
        LoginResponseDTO response = authService.login(requestDTO);
        return ResponseEntity.ok(response);
    }
}
