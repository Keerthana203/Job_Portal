package com.example.Ekam.service.impl;

import com.example.Ekam.model.*;
import com.example.Ekam.repository.*;
import com.example.Ekam.service.DropDownService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Random;

@Service
@RequiredArgsConstructor
public class DropDownServiceImpl implements DropDownService {

    private final ServiceRepository serviceRepository;
    private final ServiceStatusRepository serviceStatusRepository;
    private final RankRepository rankRepository;
    private final BranchRepository branchRepository;
    private final JobCategoryRepository jobCategoryRepository;
    private final LocationRepository locationRepository;
    private final SkillRepository skillRepository;


    @Override
    public List<JobService> getAllServices() {
        return serviceRepository.findAll();
    }

    @Override
    public List<ServiceStatus> getAllStatus() {
        return serviceStatusRepository.findAll();
    }

    @Override
    public List<Rankings> getAllRanks() {
        return rankRepository.findAll();
    }

    @Override
    public List<Branch> getAllBranch() {
        return branchRepository.findAll();
    }

    @Override
    public List<JobCategory> getAllCategory() { return jobCategoryRepository.findAll(); }

    @Override
    public List<Location> getLocations() { return locationRepository.findAll(); }

    @Override
    public List<Skills> getSkills() { return skillRepository.findAll(); }

}
