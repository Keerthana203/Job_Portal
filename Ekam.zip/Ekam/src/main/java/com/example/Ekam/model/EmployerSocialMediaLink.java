package com.example.Ekam.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "emp_social_media_links")
public class EmployerSocialMediaLink {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employer_id")
    private Employer employer;

    private String links;
}
