package com.example.Ekam.repository;

import com.example.Ekam.model.PendingEmployer;
import com.example.Ekam.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PendingEmployerRepository extends JpaRepository<PendingEmployer, Long> {

    Optional<PendingEmployer> findByUser(User user);
    void deleteByUser(User user);

}
