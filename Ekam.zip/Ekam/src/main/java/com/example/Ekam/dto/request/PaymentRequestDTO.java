package com.example.Ekam.dto.request;

import lombok.Data;

import java.math.BigDecimal;


@Data
public class PaymentRequestDTO {
    private Integer userId;
    private Integer subscriptionId;
    private BigDecimal amount;
    private Integer paymentMethodId;   // "CREDIT_CARD" or "NET_BANKING"
    private Integer cardId;         // optional
    private Long bankId;
}
