package com.example.Ekam.service.impl;


import com.example.Ekam.dto.request.CandidateProfileRequestDTO;
import com.example.Ekam.dto.response.CandidateProfileResponseDTO;
import com.example.Ekam.model.*;
import com.example.Ekam.repository.*;
import com.example.Ekam.service.CandidateProfileService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class CandidateProfileServiceImpl implements CandidateProfileService {
    private final CandidatesRepository candidatesRepository;
    private final SkillRepository skillRepository;
    private final CandidateSkillRepository candidateSkillRepository;
    private final EducationRepository educationRepository;
    private final WorkExperienceRepository workExperienceRepository;
    private final CertificationsRepository certificationRepository;
    private final CandidateSocialMediaLinkRepository socialMediaLinkRepository;

    @Override
    public Candidate saveCandidateProfile(Long userId, CandidateProfileRequestDTO profileRequest) {
        // ✅ Find candidate by userId
        Candidate candidate = candidatesRepository.findByUser_UserId(userId)
                .orElseThrow(() -> new RuntimeException("Candidate not found for userId: " + userId));

        // --- Update basic details (resume, photo, cover letter, mobile) ---
        candidate.setResumeUrl(profileRequest.getResumeUrl());
        candidate.setPhotoUrl(profileRequest.getPhotoUrl());
        candidate.setCoverLetterUrl(profileRequest.getCoverLetterUrl());
        candidate.setMobileNumber(profileRequest.getMobileNumber());

        // --- Save Candidate first ---
        candidatesRepository.save(candidate);

        // --- Save Skills ---
        if (profileRequest.getSkills() != null) {
            candidateSkillRepository.deleteAll(candidateSkillRepository.findByCandidate_User_UserId(userId));
            for (String skillName : profileRequest.getSkills()) {
                Skills skill = skillRepository.findBySkill(skillName)
                        .orElseGet(() -> {
                            Skills newSkill = new Skills();
                            newSkill.setSkill(skillName);
                            return skillRepository.save(newSkill);
                        });

                CandidateSkill candidateSkill = new CandidateSkill();
                candidateSkill.setCandidate(candidate);
                candidateSkill.setSkill(skill);
                candidateSkillRepository.save(candidateSkill);
            }
        }

        // --- Save Education ---
        if (profileRequest.getEducationList() != null) {
            educationRepository.deleteAll(educationRepository.findByCandidate_User_UserId(userId));
            for (Education edu : profileRequest.getEducationList()) {
                edu.setCandidate(candidate);
                educationRepository.save(edu);
            }
        }

        // --- Save Work Experience ---
        if (profileRequest.getWorkExperienceList() != null) {
            workExperienceRepository.deleteAll(workExperienceRepository.findByCandidate_User_UserId(userId));
            for (WorkExperience exp : profileRequest.getWorkExperienceList()) {
                exp.setCandidate(candidate);
                workExperienceRepository.save(exp);
            }
        }

        // --- Save Certifications ---
        if (profileRequest.getCertifications() != null) {
            certificationRepository.deleteAll(certificationRepository.findByCandidate_User_UserId(userId));
            for (Certifications cert : profileRequest.getCertifications()) {
                cert.setCandidate(candidate);
                certificationRepository.save(cert);
            }
        }

        // --- Save Social Media Links ---
        if (profileRequest.getSocialMediaLinks() != null) {
            socialMediaLinkRepository.deleteAll(socialMediaLinkRepository.findByCandidate_User_UserId(userId));
            for (String link : profileRequest.getSocialMediaLinks()) {
                CandidateSocialMediaLink sm = new CandidateSocialMediaLink();
                sm.setCandidate(candidate);
                sm.setLinks(link);
                socialMediaLinkRepository.save(sm);
            }
        }

        return candidate;
    }

    @Override
    public CandidateProfileResponseDTO getCandidateProfile(Long userId) {
        Candidate candidate = candidatesRepository.findByUser_UserId(userId)
                .orElseThrow(() -> new RuntimeException("Candidate not found"));

        return CandidateProfileResponseDTO.fromEntity(candidate);
    }
}
