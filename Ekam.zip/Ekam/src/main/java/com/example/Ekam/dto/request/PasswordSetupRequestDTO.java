package com.example.Ekam.dto.request;


import lombok.Data;

@Data
public class PasswordSetupRequestDTO {
    private String email;
    private String password;
}
