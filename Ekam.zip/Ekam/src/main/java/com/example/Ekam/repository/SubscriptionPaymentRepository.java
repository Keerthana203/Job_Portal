package com.example.Ekam.repository;

import com.example.Ekam.model.SubscriptionPayment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SubscriptionPaymentRepository extends JpaRepository<SubscriptionPayment, Integer> {
    List<SubscriptionPayment> findByEmployer_User_UserId(Integer userId);
}
