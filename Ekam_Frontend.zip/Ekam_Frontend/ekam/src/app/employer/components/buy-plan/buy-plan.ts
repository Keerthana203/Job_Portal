import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { EmployerService } from '../../services/employer-service';
import { CreditCard } from '../../../shared/models/creditCard.model';
import { PlanAdmin } from '../../../shared/models/planAdmin.model';
import { ActivatedRoute, Router } from '@angular/router';
import { Bank } from '../../../shared/models/bank.model';

@Component({
  selector: 'app-buy-plan',
  standalone: false,
  templateUrl: './buy-plan.html',
  styleUrl: './buy-plan.scss'
})
export class BuyPlan implements OnInit{

  // selectedTab: 'card' | 'netbanking' = 'card'; // default tab

  // savedCards: CreditCard[] = [];
  // banks: string[] = [];
  // otherBanks: string[] = [];

  // selectedCard!: CreditCard;
  // selectedBank: string = '';

  // plan!: PlanAdmin;
  // taxValue: number = 0;
  // totalAmount: number = 0;

  // userId!: number;
  // planId!: number;

  // constructor(
  //   private snackBar: MatSnackBar,
  //   private employerService: EmployerService,
  //   private route: ActivatedRoute,
  //   private cdr: ChangeDetectorRef,
  // ) {}

  // ngOnInit(): void {
  //   this.userId = Number(localStorage.getItem('userId'));
  //   this.planId = Number(this.route.snapshot.paramMap.get('id'));

  //   if (!this.userId) {
  //     this.snackBar.open('User not logged in', 'Close', { duration: 3000 });
  //     return;
  //   }

  //   if (this.planId) {
  //     this.employerService.getPlanById(this.planId).subscribe({
  //       next: (data: PlanAdmin) => {
  //         this.plan = data;
  //         this.calculateSummary();
  //          this.cdr.detectChanges();
  //       },
  //       error: () => {
  //         this.snackBar.open('Failed to fetch plan details', 'Close', { duration: 3000 });
  //       }
  //     });
  //   }

  //   // Fetch saved cards
  //   this.employerService.getSavedCards(this.userId).subscribe({
  //     next: (cards) => {
  //       this.savedCards = cards;
  //     },
  //     error: () => {
  //       this.snackBar.open('Failed to fetch saved cards', 'Close', { duration: 3000 });
  //     }
  //   });

  //   // Fetch banks
  //   this.employerService.getBanks(this.userId).subscribe({
  //     next: (bankList) => {
  //       this.banks = bankList.map(b => b.name);
  //       if (this.banks.length > 0) {
  //         this.selectedBank = this.banks[0];
  //       }
  //       this.otherBanks = ['HDFC Bank', 'ICICI Bank', 'Yes Bank', 'Kotak Mahindra'];
  //     },
  //     error: () => {
  //       this.snackBar.open('Failed to fetch banks', 'Close', { duration: 3000 });
  //     }
  //   });
  // }

  // calculateSummary(): void {
  //   this.taxValue = this.plan.price * 0.05;  // 5% tax
  //   this.totalAmount = this.plan.price + this.taxValue;
  // }

  // onSave() {
  //   if (this.selectedTab === 'card') {
  //     this.saveCardPayment();
  //   } else {
  //     this.saveBankPayment();
  //   }
  // }

  // private saveCardPayment() {
  //   const selectedCard = this.savedCards.find(c => c.number === this.selectedCard);
  //   if (!selectedCard) {
  //     this.snackBar.open('No card selected', 'Close', { duration: 3000 });
  //     return;
  //   }

  //   this.employerService.addCard(selectedCard, this.userId, this.planId).subscribe({
  //     next: () => {
  //       this.snackBar.open('Payment successful via Card', 'Close', { duration: 3000 });
  //     },
  //     error: () => {
  //       this.snackBar.open('Payment failed', 'Close', { duration: 3000 });
  //     }
  //   });
  // }

  // private saveBankPayment() {
  //   if (!this.selectedBank) {
  //     this.snackBar.open('No bank selected', 'Close', { duration: 3000 });
  //     return;
  //   }

  //   this.employerService.saveBank(this.selectedBank, this.userId, this.planId).subscribe({
  //     next: () => {
  //       this.snackBar.open('Payment successful via Bank', 'Close', { duration: 3000 });
  //     },
  //     error: () => {
  //       this.snackBar.open('Payment failed', 'Close', { duration: 3000 });
  //     }
  //   });
  // }

  // onProceed() {
  //   this.employerService.
  // }

  selectedTab: 'card' | 'netbanking' = 'card'; // default tab

  savedCards: CreditCard[] = [];
  banks: Bank[] = [];
  otherBanks: Bank[] = [];

  selectedCard: CreditCard | null = null;
  selectedBank: Bank | null = null;
  // selectedBank: string = '';
  selectedPaymentMethodId!: number;


  //for new card form
  newCardNumber: string = '';
  newCardExpiry: string = '';
newCardName: string = '';
newCardCVV: string = '';
  newCard: Partial<CreditCard> = {
    nameOnCard: '',
    expiry: '',
    cvv: ''
  };

  //this fixes the error
  saveCard: boolean = false;

  plan!: PlanAdmin;
  taxValue: number = 0;
  totalAmount: number = 0;

  userId!: number;
  planId!: number;

  

  constructor(
    private snackBar: MatSnackBar,
    private employerService: EmployerService,
    private route: ActivatedRoute,
    private cdr: ChangeDetectorRef,
    private router: Router,
  ) {}

  ngOnInit(): void {
    this.userId = Number(localStorage.getItem('userId'));
    this.planId = Number(this.route.snapshot.paramMap.get('id'));

    if (!this.userId) {
      this.snackBar.open('User not logged in', 'Close', { duration: 3000 });
      return;
    }

    if (this.planId) {
      this.employerService.getPlanById(this.planId).subscribe({
        next: (data: PlanAdmin) => {
          this.plan = data;
          this.calculateSummary();
          this.cdr.detectChanges();
        },
        error: () => {
          this.snackBar.open('Failed to fetch plan details', 'Close', { duration: 3000 });
        }
      });
    }

    // Fetch saved cards
    this.employerService.getSavedCards(this.userId).subscribe({
      next: (cards) => {
        this.savedCards = cards;
        this.cdr.detectChanges();
      },
      error: () => {
        this.snackBar.open('Failed to fetch saved cards', 'Close', { duration: 3000 });
      }
    });

    // Fetch banks
    // this.employerService.getBanks(this.userId).subscribe({
    //   next: (bankList: Bank[]) => {
    //     console.log('FEtched',bankList)
    //     this.banks = bankList.map(b => b.bankName);
    //     if (this.banks.length > 0) {
    //       this.selectedBank = this.banks[0];
    //     }
    //     this.otherBanks = ['HDFC Bank', 'ICICI Bank', 'Yes Bank', 'Kotak Mahindra'];
    //     this.selectedBank = '';
    //   },
    //   error: () => {
    //     this.snackBar.open('Failed to fetch banks', 'Close', { duration: 3000 });
    //   }
    // });
    this.employerService.getBanks(this.userId).subscribe({
  next: (bankList: Bank[]) => {
    this.banks = bankList;
    if (this.banks.length > 0) {
      this.selectedBank = this.banks[0];
    }
    this.otherBanks = [
      { id: 101, bankName: 'HDFC Bank' },
      { id: 102, bankName: 'ICICI Bank' },
      { id: 103, bankName: 'Yes Bank' },
      { id: 104, bankName: 'Kotak Mahindra' }
    ];
  }
});
  }

  calculateSummary(): void {
    this.taxValue = this.plan.price * 0.05;  // 5% tax
    this.totalAmount = this.plan.price + this.taxValue;
  }

  onSave() {
    if (this.selectedTab === 'card') {
      this.saveCardPayment();
    } else {
      this.saveBankPayment();
    }
  }



  private saveCardPayment() {
  if (this.selectedCard) {
    // Case 1: User selected an existing saved card
    this.snackBar.open('You can proceed to payment', 'Close', { duration: 3000 });
    return;
  }

  // Case 2: User entered new card details
  if (!this.newCardNumber || !this.newCardExpiry || !this.newCardName || !this.newCardCVV) {
    this.snackBar.open('Please fill all card details', 'Close', { duration: 3000 });
    return;
  }

  const cardPayload: CreditCard = {
    last4: this.newCardNumber.slice(-4),
    expiry: this.newCardExpiry,
    nameOnCard: this.newCardName,
    isDefault: this.saveCard // true if checkbox ticked
  };

  const cvv = this.newCardCVV; // use only here, don't store

  this.employerService.addCard(cardPayload, this.userId, this.planId).subscribe({
    next: (savedCard) => {
      this.snackBar.open('Card saved successfully', 'Close', { duration: 3000 });

      // update UI
      this.savedCards.push(savedCard);
      this.cdr.detectChanges();

      // clear form fields
      this.newCardNumber = '';
      this.newCardExpiry = '';
      this.newCardName = '';
      this.newCardCVV = '';
      this.saveCard = false;
      
    },
    error: () => {
      this.snackBar.open('Unable to save card', 'Close', { duration: 3000 });
    }
  });
}


  /**
   * Save bank payment
   */
  private saveBankPayment() {
    if (!this.selectedBank) {
      this.snackBar.open('No bank selected', 'Close', { duration: 3000 });
      return;
    }

    this.employerService.saveBank(this.selectedBank.bankName, this.userId, this.planId).subscribe({
      next: () => {
        this.snackBar.open('You may now proceed', 'Close', { duration: 3000 });
      },
      error: () => {
        this.snackBar.open('cannot access bank', 'Close', { duration: 3000 });
      }
    });
  }

  onCardSelect(card: CreditCard) {
  this.selectedCard = card;
  this.selectedBank = null; // clear bank if switching to card
  this.selectedPaymentMethodId = 13; // hardcoded CREDIT_CARD enum id
}

onBankSelect(bank: Bank) {
  this.selectedBank = bank;
  this.selectedCard = null; // clear card if switching to bank
  this.selectedPaymentMethodId = 14; // hardcoded NET_BANKING enum id
}


  onProceed() {

    if (!this.selectedPaymentMethodId) {
    this.snackBar.open('Please select a payment method', 'Close', { duration: 3000 });
    return;
  }

  const paymentPayload = {
    userId: this.userId,
    subscriptionId: this.planId,
    amount: this.plan.price,
    paymentMethodId: this.selectedPaymentMethodId,
    cardId: this.selectedCard ? this.selectedCard.id : null,
    bankId: this.selectedBank ? this.selectedBank.id : null
  };

  this.employerService.makePayment(paymentPayload).subscribe({
    next: () => {
      this.snackBar.open('Plan subscription successful', 'Close', { duration: 3000 });
      // optionally refresh user subscriptions or navigate
      this.router.navigate(['/employer/home']);
    },
    error: (err) => {
      console.error('Payment failed', err);
      this.snackBar.open('Payment failed. Please try again.', 'Close', { duration: 3000 });
    }
  });

  }

}
