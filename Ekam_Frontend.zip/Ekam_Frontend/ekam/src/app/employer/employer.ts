import { Component } from '@angular/core';

@Component({
  selector: 'app-employer',
  standalone: false,
  templateUrl: './employer.html',
  styleUrl: './employer.scss'
})
export class Employer {

}
