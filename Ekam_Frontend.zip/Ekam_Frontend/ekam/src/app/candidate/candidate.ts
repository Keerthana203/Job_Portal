import { Component } from '@angular/core';

@Component({
  selector: 'app-candidate',
  standalone: false,
  templateUrl: './candidate.html',
  styleUrl: './candidate.scss'
})
export class Candidate {

}
