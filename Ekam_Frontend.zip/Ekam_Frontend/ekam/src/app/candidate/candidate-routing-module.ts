import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Candidate } from './candidate';
import { Home } from './components/home/home';
import { CandidateProfile } from './components/candidate-profile/candidate-profile';


const routes: Routes = [

  {path: '', component: Candidate,
    children: [
      {path: 'home', component: Home},
      {path: 'profile', component: CandidateProfile,}
    ]
  }

]



@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})




// const routes: Routes = [

//   {path: '', component: Employer,
//     children: [
//       {path: 'home', component: Home},
//       {path: 'post-job', component: PostJob},
//       { path: 'view-plans', component: ViewPlan },
//       { path: 'buy-plan/:id', component: BuyPlan },
//     ]
//   }

// ];



export class CandidateRoutingModule { }
