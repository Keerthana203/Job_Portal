import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { CandidateProfile } from '../components/candidate-profile/candidate-profile';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CandidateService {

  private base_url = `${environment.baseUrl}/api`;

  constructor(private http: HttpClient) {}

  // saveCandidateProfile(userId: number, profile: CandidateProfile): Observable<any> {
  //   return this.http.post(`${this.base_url}/${userId}/save`, profile);
  // }


  saveCandidateProfile(profile: CandidateProfile): Observable<any> {
    return this.http.post(`${this.base_url}/save`, profile);
  }

  uploadFile(file: File): Observable<string> {
    const formData = new FormData();
    formData.append('file', file);
    return this.http.post<string>(`${this.base_url}/upload`, formData);
  }

  getCandidateProfile(userId: number): Observable<CandidateProfile> {
    return this.http.get<CandidateProfile>(`${this.base_url}/${userId}/profile`);
  }
  
}
