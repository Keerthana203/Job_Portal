import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CandidateService } from '../../services/candidate-service';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatChipInputEvent } from '@angular/material/chips';

@Component({
  selector: 'app-candidate-profile',
  standalone: false,
  templateUrl: './candidate-profile.html',
  styleUrl: './candidate-profile.scss'
})
export class CandidateProfile implements OnInit{

  profileForm!: FormGroup;
  resumeUrl?: string;
  coverLetterUrl?: string;
  photoUrl?: string;
  separatorKeysCodes: number[] = [ENTER, COMMA];

  constructor(private fb: FormBuilder, private candidateService: CandidateService) {}

  ngOnInit(): void {
    this.profileForm = this.fb.group({
      userId: [1], // you can set this dynamically from login
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      mobile: ['', Validators.required],
      skills: this.fb.array([]),
      socialMediaLinks: this.fb.array([]),
      educationList: this.fb.array([]),
      workExperienceList: this.fb.array([])
    });
  }


addSkillFromInput(event: MatChipInputEvent
): void {
  const value = (event.value || '').trim();
  if (value) {
    this.skills.push(this.fb.control(value, Validators.required));
  }
  event.chipInput!.clear();
}

removeSkill(index: number): void {
  this.skills.removeAt(index);
}


  get skills(): FormArray {
    return this.profileForm.get('skills') as FormArray;
  }
  get socialMediaLinks(): FormArray {
    return this.profileForm.get('socialMediaLinks') as FormArray;
  }
  get educationList(): FormArray {
    return this.profileForm.get('educationList') as FormArray;
  }
  get workExperienceList(): FormArray {
    return this.profileForm.get('workExperienceList') as FormArray;
  }

  addSkill() {
    this.skills.push(this.fb.control('', Validators.required));
  }

  addSocialMedia() {
    this.socialMediaLinks.push(this.fb.control('', Validators.required));
  }

  addEducation() {
    this.educationList.push(this.fb.group({
      degreeId: ['', Validators.required],
      specializationId: ['', Validators.required],
      institutionId: ['', Validators.required],
      completedYear: ['', Validators.required]
    }));
  }

  addWorkExperience() {
    this.workExperienceList.push(this.fb.group({
      companyName: ['', Validators.required],
      role: ['', Validators.required],
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      description: ['']
    }));
  }

  // onFileUpload(event: any, type: string) {
  //   const file = event.target.files[0];
  //   if (file) {
  //     this.candidateService.uploadFile(file).subscribe((res: string) => {
  //       if (type === 'resume') this.resumeUrl = res.url;
  //       if (type === 'coverLetter') this.coverLetterUrl = res.url;
  //       if (type === 'photo') this.photoUrl = res.url;
  //     });
  //   }
  // }

  onFileUpload(event: any, type: string) {
  const file = event.target.files[0];
  if (file) {
    this.candidateService.uploadFile(file).subscribe((url: string) => {
      if (type === 'resume') this.resumeUrl = url;
      if (type === 'coverLetter') this.coverLetterUrl = url;
      if (type === 'photo') this.photoUrl = url;
    });
  }
}


  saveProfile() {
    const profileData = { 
      ...this.profileForm.value,
      resumeUrl: this.resumeUrl,
      coverLetterUrl: this.coverLetterUrl,
      photoUrl: this.photoUrl
    };

    this.candidateService.saveCandidateProfile(profileData).subscribe({
      next: () => alert('Profile saved successfully!'),
      error: (err) => console.error(err)
    });
  }

}
