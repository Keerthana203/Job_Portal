export interface WorkExperience {
  companyName: string;
  role: string;
  startDate: string;
  endDate: string;
  description: string;
}