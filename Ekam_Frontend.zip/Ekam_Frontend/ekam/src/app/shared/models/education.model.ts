export interface Education {
  degreeId: number;
  specializationId: number;
  institutionId: number;
  completedYear: number;
}
