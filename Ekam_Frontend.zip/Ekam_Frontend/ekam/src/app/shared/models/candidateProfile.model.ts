import { Education } from "./education.model";
import { WorkExperience } from "./workExperience.model";

export interface CandidateProfile {
  userId: number;
  firstName: string;
  lastName: string;
  email: string;
  mobile: string;
  educationList: Education[];
  workExperienceList: WorkExperience[];
  skills: string[];
  socialMediaLinks: string[];
  resumeUrl?: string;
  coverLetterUrl?: string;
  photoUrl?: string;
}