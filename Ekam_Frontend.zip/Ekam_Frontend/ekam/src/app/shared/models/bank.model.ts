export interface Bank {
  id: number;
  bankName: string;
}