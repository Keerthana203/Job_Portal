export interface CreditCard {
//   last4: string;
//   expiry: string;
//   cvv: string;
//   nameOnCard: string;
//   fullNumber: string;
 id?: number;              // optional, DB-generated
  last4: string;            // last 4 digits only (required)
  expiry: string;           // format MM/YY or MM/YYYY
  cvv?: string;             // used only at payment time, never stored
  nameOnCard: string;       // cardholder name
  isDefault?: boolean; 
}