export interface Payment {
    
}