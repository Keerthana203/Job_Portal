import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { catchError, EMPTY, throwError } from 'rxjs';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const token = localStorage.getItem('token');
  const router = inject(Router);
  const snackBar = inject(MatSnackBar);

  // Skip adding token for login or register requests
  // if (req.url.endsWith('/login') || req.url.endsWith('/register')) {
  //   return next(req);
  // }

  // const cloned = req.clone({
  //   setHeaders: {
  //     Authorization: `Bearer ${token}`
  //   }
  // });

  if (
    req.url.includes('/login') ||
    req.url.includes('/register') ||
    req.url.includes('/otp') ||
    req.url.includes('/setupPassword')
  ) {
    return next(req);
  }

  const authReq = token
    ? req.clone({
        setHeaders: { Authorization: `Bearer ${token}` },
      })
    : req;

  return next(authReq).pipe(
    catchError((error: any) => {
      if (error.status === 500 && error.error?.message?.includes('expired')) {
        snackBar.open('Session expired. Please login again.', 'Close', {
          duration: 3000,
          verticalPosition: 'bottom',
        });
        localStorage.removeItem('token');
        router.navigate(['/login']);
        return EMPTY;
      } else if (error.status === 401) {
        snackBar.open('Unauthorized access. Please login.', 'Close', {
          duration: 3000,
          verticalPosition: 'top',
        });
        router.navigate(['/login']);
        return EMPTY;
      }
      return throwError(() => error);
    })
  );
};
